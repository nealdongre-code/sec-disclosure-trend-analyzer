# SEC Exhibit 10 research dataset — research-v1.0

**Educational and research use only. No guarantee of accuracy, completeness or reliability. Do not rely on this information for financial, investment, commercial, legal or other decisions.** Consult original SEC filings and qualified professionals. Independent project; not affiliated with or endorsed by the SEC.

Release date: November 4, 2026 (America/New_York). This is a local, provisional research release. It has not been published online and is not a dashboard.

## Contents and result

`dataset.csv` provides a readable table. `dataset.json` provides the same 114 records with source provenance, a disclaimer and coverage metadata for future static filtering. `coverage.json` contains the measured counts. Distribute the CSV with this README and `DISCLAIMER.txt`.

The fixed sample contains 114 Exhibit 10 attachments from 19 issuers and 77 filings. Years: 2021 (37), 2023 (40), 2025 (37). Forms: 10-K (30), 10-Q (45), 8-K (39). Industries: technology (24), financial services (24), healthcare (21), industrials (24), energy (21).

| AI primary category | Records |
|---|---:|
| Compensation & Benefits | 66 |
| Financing & Credit | 17 |
| Employment & Separation | 9 |
| Commercial Supply & Services | 8 |
| Capital Projects & Facilities | 3 |
| Acquisitions & Divestitures | 2 |
| Technology & Intellectual Property | 1 |
| Strategic Partnerships | 0 |
| Other / Unclassified | 8 |

106 records received substantive primary categories. Eight intentional Other records concern governance, indemnification or executive aircraft use; their purposes are described in their reasons. One licensing amendment also has a Strategic Partnerships secondary tag. Six records have medium ordinal confidence, requiring particular care around primary-category judgments. These are not calibrated probabilities or verified accuracy scores.

## Method and checks

Thirty previously completed substantive-section AI reviews are carried forward. The remaining 84 received one short AI pass using up to 1,400 opening characters; three exceptions (D033, D102 and D103) received expanded purpose/recital reads. Clear records were not subjected to repeated clause reviews. Some sources were re-fetched to recover incomplete tool output, and one source required a later retry after temporary HTTP 503 failures. All 114 source-document URLs were successfully retrieved during AI preparation; the per-record successful-check timestamp distinguishes earlier pilot retrieval from this completion pass.

The assistant assigned categories, secondary tags, instrument types and paraphrased reasons. Retrieval code did not assign semantic labels. Definitions and contextual decisions are in `RELEASE_PROTOCOL.md` and the preceding pilot protocol. Employment and compensation names deliberately broaden the original executive-only labels. The assistant also developed the taxonomy and knew prior results; this is neither a blinded test nor independent validation.

The final checks confirmed 114 unique IDs matching the original sample, complete metadata/classification fields, valid categories, source traceability, evidence offsets, CSV/JSON consistency and unchanged original-study artifacts. A small eight-record assistant consistency check covers awards, a credit addendum, severance, transaction tax matters, services, R&D and a lease assignment. It is not a human or independent accuracy assessment.

Source byte hashes for ten later responses differed from the initial study: D033, D054, D056, D057, D078, D079, D081, D083, D102 and D103. Both reference and current input hashes are retained; differences are flagged rather than treated as proof of legal changes. For the three expanded exception reads, previously inspected normalized evidence windows matched despite response-byte variation. Document-wide equivalence was not established. Do not use raw hashes alone to infer new or amended economic agreements.

SEC access remained public-only with the authorized contact header and conservative sequential pacing. No paid AI API invocation, credit purchase or allowance reset was initiated. Full documents were temporary in-memory inputs; release files retain only metadata, classifications, source URLs, hashes and paraphrased reasons. Evidence audit files contain offsets/hashes, not excerpts or bodies. The supplied retrieval contact email is not included in the release.

## Interpretation and limitations

This is a purposive feasibility sample, not a census or statistically representative industry sample. The two unfilled combinations remain healthcare/2021/8-K and energy/2025/8-K. There are no 2022 or 2024 observations. Do not draw continuous annual or industry-wide trend conclusions from this release.

The counting unit is **exhibit attachments**, not distinct transactions, underlying agreements or new deals. Award forms, plans, amendments, addenda, restatements and bundled instruments are explicitly identified where evident. Cross-filer deduplication, original-incorporated-document resolution, materiality judgments and complete agreement-family linkage remain unvalidated.

Filings define the year, not agreement execution or acceptance dates. D076–D077 preserve the SEC-published 2021 filing date while flagging the differing 2022 acceptance/accession year. Classifications concern broad purpose based on limited reviewed evidence, not full legal review or redacted obligations. Source availability can change after retrieval.

## Next phase

The dataset is ready for a bounded prototype of year/industry/category/form filters, coverage statistics and SEC source navigation. Any public interface must display the educational/research-only, no-guarantee and no-reliance notice conspicuously next to its title/results and explain the sample limits. No AI or live SEC retrieval is needed for visitor queries. Dashboard design and construction remain a subsequent phase.
